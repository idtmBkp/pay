module.exports = {
  index(req, res) {
    return res.render('dashboard/index');
  },
};
