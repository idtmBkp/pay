$(document).ready(() => {
  /**
   * Alerts
   */
  setTimeout(() => {
    const alert = document.querySelector('.alert');

    if (alert) alert.className += ' alert-hidden';
  }, 3000);
});
